<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sit-in Monitoring System</title>
    <link rel="stylesheet" href="styles.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            background-color: whitesmoke;
            display: flex;
        }
        .sidebar {
            width: 250px;
            background: #4f0079;
            color: white;
            padding: 20px;
            height: 100vh;
            transition: width 0.3s;
            overflow: hidden;
        }
        .sidebar.collapsed {
            width: 70px;
        }
        .sidebar h3, .sidebar ul li a {
            transition: opacity 0.3s;
        }
        .sidebar.collapsed h3, .sidebar.collapsed ul li a {
            opacity: 0;
        }
        .sidebar ul {
            list-style: none;
            padding: 0;
        }
        .sidebar ul li {
            padding: 10px;
            text-align: center;
        }
        .sidebar ul li a {
            color: white;
            text-decoration: none;
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 10px;
        }
        .sidebar ul li a:hover {
            background: #6a008f;
            border-radius: 5px;
        }
        .toggle-btn {
            background: #4f0079;
            color: white;
            border: none;
            cursor: pointer;
            padding: 10px;
            width: 100%;
            text-align: left;
        }
        .main-content {
            flex-grow: 1;
            padding: 20px;
            display: flex;
            flex-direction: column;
            align-items: first baseline;
            width: 100%;
        }
        .stats-container {
            display: flex;
            gap: 20px;
            justify-content: right;
            flex-wrap: wrap;
        }
        .stat-box, .chart, .announcement-section {
            background: white;
            padding: 20px;
            border-radius: 50px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            text-align: center;
            width: 500%;
            max-width: 400px;
        }
        .stat-box {
            width: 250px;
        }
    </style>
</head>
<body>
    <div class="sidebar" id="sidebar">
        <center><img src="profile.png" alt="User Profile"></center>
        <center><h3>John Don</h3></center>
        <ul>
            <li><a href="#"><i class="fas fa-home"></i> Home</a></li>
            <li><a href="#"><i class="fas fa-user"></i> Profile</a></li>
            <li><a href="#"><i class="fas fa-bullhorn"></i> Announcements</a></li>
            <li><a href="#"><i class="fas fa-chart-bar"></i> Reports</a></li>
            <li><a href="#"><i class="fas fa-cog"></i> Settings</a></li>
            <li><a href="#"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
        </ul>
    </div>
    <div class="main-content">
        <h1>Dashboard</h1>
        <div class="stats-container">
            <div class="stat-box"><h3>Students</h3><p>150</p></div>
            <div class="stat-box"><h3>Sessions</h3><p>45</p></div>
            <div class="stat-box"><h3>Pending Requests</h3><p>12</p></div>
        </div>
        <div class="chart">
            <h3>Monthly Attendance</h3>
            <canvas id="attendanceChart"></canvas>
        </div>
        <div class="announcement-section">
            <h3>Announcements</h3>
            <p><strong>CCS Admin | 2025-Feb-03</strong></p>
            <p>The College of Computer Studies will open registration for Sit-in privilege starting tomorrow.</p>
            <p><strong>Feb 14:</strong> Sit-in registration is now open!</p>
            <p><strong>Feb 10:</strong> Please follow the updated rules.</p>
        </div>
    </div>
    <script>
        function toggleSidebar() {
            document.getElementById('sidebar').classList.toggle('collapsed');
        }
        const ctx = document.getElementById('attendanceChart').getContext('2d');
        new Chart(ctx, {
            type: 'bar',
            data: {
                labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May'],
                datasets: [{
                    label: 'Attendance',
                    data: [30, 45, 25, 50, 40],
                    backgroundColor: 'purple'
                }]
            }
        });
    </script>
</body>
</html>
