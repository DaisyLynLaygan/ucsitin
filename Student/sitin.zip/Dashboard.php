<?php
session_start();

// Check if user is logged in
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

$username = $_SESSION['username'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <script src="https://kit.fontawesome.com/a076d05399.js"></script>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
        }
        .sidebar {
            width: 250px;
            background: #6a0dad;
            color: white;
            position: fixed;
            height: 100vh;
            padding: 20px;
        }
        .sidebar h2 {
            text-align: center;
            margin-bottom: 20px;
        }
        .sidebar ul {
            list-style: none;
            padding: 0;
        }
        .sidebar ul li {
            padding: 15px;
        }
        .sidebar ul li a {
            color: white;
            text-decoration: none;
            display: block;
        }
        .sidebar ul li a:hover {
            background: #5a0c9b;
            border-radius: 5px;
        }
        .main-content {
            margin-left: 250px;
            padding: 20px;
            background: whitesmoke;
        }
        .header {
            background: #6a0dad;
            color: white;
            padding: 15px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 2px 2px 5px rgba(0, 0, 0, 0.1);
        }
        .logout-btn {
            background: red;
            color: white;
            padding: 10px;
            border: none;
            cursor: pointer;
            border-radius: 5px;
        }
        .logout-btn:hover {
            background: darkred;
        }
        .dashboard-cards {
            display: flex;
            gap: 20px;
            margin-top: 20px;
        }
        .card {
            flex: 1;
            padding: 20px;
            background: #8e44ad;
            color: white;
            border-radius: 10px;
            text-align: center;
        }
    </style>
</head>
<body>

<div class="sidebar">
    <h2>Admin Panel</h2>
    <ul>
        <li><a href="#"><i class="fas fa-home"></i> Dashboard</a></li>
        <li><a href="#"><i class="fas fa-user"></i> Students</a></li>
        <li><a href="#"><i class="fas fa-calendar"></i> Attendance</a></li>
        <li><a href="#"><i class="fas fa-cog"></i> Settings</a></li>
        <li><a href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
    </ul>
</div>

<div class="main-content">
    <div class="header">
        <h2>Welcome, <?php echo htmlspecialchars($username); ?></h2>
        <a href="logout.php">
            <button class="logout-btn">Logout</button>
        </a>
    </div>

    <div class="dashboard-cards">
        <div class="card">
            <h3>2478</h3>
            <p>Total Students</p>
        </div>
        <div class="card">
            <h3>983</h3>
            <p>Present Today</p>
        </div>
        <div class="card">
            <h3>1256</h3>
            <p>Absent Today</p>
        </div>
        <div class="card">
            <h3>652</h3>
            <p>Pending Approvals</p>
        </div>
    </div>
</div>

</body>
</html>
