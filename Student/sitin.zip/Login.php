<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CCS Sitin Monitoring System</title>
    <link rel="stylesheet" href="https://www.phptutorial.net/app/css/style.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: Arial, sans-serif;
        }
        .container {
            display: flex;
            height: 100vh;
            box-shadow: 5px 5px 15px rgba(0, 0, 0, 0.2); /* Added box shadow */
        }
        .left {
            flex: 1;
            display: flex;
            align-items: center;
            justify-content: center;
            background-color: #DAD2FF;
            background-image: url("OP.jpg");
        }
        .right {
            flex: 1;
            display: flex;
            align-items: center;
            justify-content: center;
            background-color: whitesmoke;
        }
        .login-box {
            width: 320px;
            padding: 25px;
            background: white;
            border-radius: 8px;
            box-shadow: 5px 5px 15px rgba(0, 0, 0, 0.2); /* Added box shadow */
            text-align: center;
        }
        .login-box img {
            width: 30%;
            height: auto;
            margin-bottom: 15px; /* Added space below the logo */
            padding-top: 10px; /* Moved the logo slightly above */
        }
        .login-box h2 {
            margin-bottom: 20px;
            text-align: center;
        }
        .input-group {
            margin-bottom: 15px;
            text-align:left;
        }
        .input-group label {
            display: block;
            margin-bottom: 5px;
        }
        .input-group input {
            width: 100%;
            padding: 8px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        .btn {
            width: 100%;
            padding: 10px;
            background: #007BFF;
            border: none;
            color: white;
            cursor: pointer;
            border-radius: 5px;
            font-size: 16px;
            margin-top:10px;
        }
        .btn:hover {
            background: #0056b3;
        }
    
    </style>
</head>
<body>

<div class="container">
    <div class="left"></div>
    <div class="right">
        <form method="POST" style="background-color: whitesmoke;">
            <center>
                <img src="../sitin/CCS LOGO.png" width="30%" height="auto"/>
            </center>
            <h1><b>CCS Sitin Monitoring System</b></h1>
            <div>
                <label for="username">Username:</label>
                <input type="text" name="username" id="username">
            </div>
            <div>
                <label for="password">Password:</label>
                <input type="password" name="password" id="password">
            </div>
            <section>
                <button type="submit">Login</button>
                <a href="register.php">Sign Up</a>
            </section>
        </form>
    </div>
</div>

</body>
</html>
