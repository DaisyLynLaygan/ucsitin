<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://www.phptutorial.net/app/css/style.css">
    <title>Register</title>
</head>
<body>
    <main>
    <form  method="POST" style="background-color:whitesmoke;">
        <h1><b>Sing Up!</b></h1>
        <div>
            <label for="idno">IDno:</label>
            <input type="number" name="idno" id="idno">
        </div>

        <div>
            <label for="lastname">Lastname:</label>
            <input type="text" name="lastname" id="lastname">
        </div>
        <div>
            <label for="firstname">Firstname:</label>
            <input type="text" name="firstname" id="firstname">
        </div>

        <div>
            <label for="midname">Midname:</label>
            <input type="text" name="midname" id="midname">
        </div>
        <div>
            <label for="course">Course:</label>
            <input type="text" name="course" id="course">
        </div>

        <div>
            <label for="yearlevel">Yearlevel:</label>
            <input type="num" name="yearlevel" id="yearlevel">
        </div>
        <div>
            <label for="email address">Email Address:</label>
            <input type="email" name="email address" id="email address">
        </div>
        <div>
            <label for="username">Username:</label>
            <input type="text" name="username" id="username">
        </div>
        <div>
            <label for="password">Password:</label>
            <input type="password" name="password" id="password">
        </div>

        <section>
            <button type="submit">Sing In</button>
            <a href="register.php">Register</a>
        </section>
        </form>
</main>
</body>
</html>
